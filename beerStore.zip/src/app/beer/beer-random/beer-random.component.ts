import { Component, OnInit } from '@angular/core';
import {Subscription} from 'rxjs';
import {BeersService} from '../_services/beers.service';

@Component({
  selector: 'app-beer-random',
  templateUrl: './beer-random.component.html',
  styleUrls: ['./beer-random.component.less']
})
export class BeerRandomComponent implements OnInit {

  // tslint:disable-next-line:variable-name
  public readonly non_Alochalic_Beer = 'ABV<=5';
  private subGetBeerItem: Subscription;
  // tslint:disable-next-line:variable-name
  private _beerItem: object;


  get beerItem(): object {
    return this._beerItem;
  }

  set beerItem(value: object) {
    this._beerItem = value;
  }

  constructor(private beerService: BeersService) { }

  ngOnInit(): void {
    this.getRandomBeer();
  }

  public getRandomBeer(beerType: string = null) {
    let params;
    params = beerType ?  '/random?' + this.non_Alochalic_Beer : '/random';
    this.subGetBeerItem = this.beerService.getBeersList(params).subscribe((response) => {
      this.beerItem = response;
    }, (error) => {
      console.log(error);
    }, () => {

    });
  }
}
