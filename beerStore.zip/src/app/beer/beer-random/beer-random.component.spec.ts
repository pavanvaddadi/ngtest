import { async, ComponentFixture, TestBed,  fakeAsync, tick	 } from '@angular/core/testing';

import { BeerRandomComponent } from './beer-random.component';
import {Observable, of} from 'rxjs';
import {Injectable, NO_ERRORS_SCHEMA} from '@angular/core';
import {BeersService} from '../_services/beers.service';
import {HttpClientModule} from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import {By} from '@angular/platform-browser';

const mockedBeer = {
  id: 2,
  name: 'Trashy Blonde',
  tagline: 'You Know You Shouldn\'t',
  first_brewed: '04/2008',
  // tslint:disable-next-line:max-line-length
  description: 'A titillating, neurotic, peroxide punk of a Pale Ale. Combining attitude, style, substance, and a little bit of low self esteem for good measure; what would your mother say? The seductive lure of the sassy passion fruit hop proves too much to resist. All that is even before we get onto the fact that there are no additives, preservatives, pasteurization or strings attached. All wrapped up with the customary BrewDog bite and imaginative twist.',
  image_url: 'https://images.punkapi.com/v2/2.png',
  abv: 4.1,
  ibu: 41.5,
  target_fg: 1010,
  target_og: 1041.7,
  ebc: 15,
  srm: 15,
  ph: 4.4,
  attenuation_level: 76,
  food_pairing: [
    'Fresh crab with lemon',
    'Garlic butter dipping sauce',
    'Goats cheese salad',
    'Creamy lemon bar doused in powdered sugar'
  ],
  contributed_by: 'Sam Mason <samjbmason>'
};


@Injectable()
export class MockBeerService  extends BeersService {

  public getBeersList(params?: null): Observable<any> {
    return of(mockedBeer);
  }

}

fdescribe('BeerRandomComponent', () => {
  let component: BeerRandomComponent;
  let fixture: ComponentFixture<BeerRandomComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BeerRandomComponent ],
     // schemas: [NO_ERRORS_SCHEMA],
	   imports: [HttpClientTestingModule]
	}).overrideComponent(BeerRandomComponent, {
      set: {
        providers: [
          {provide: BeersService, useClass: MockBeerService },
        ]
      }
    })
    .compileComponents().then();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BeerRandomComponent);
    component = fixture.componentInstance;
    console.log(component);
    fixture.detectChanges();
  });

  fit('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should fetch data and initialize beers list', () => {
    spyOn(component, 'getRandomBeer');
    component.ngOnInit();
    fixture.detectChanges();
    expect(component.getRandomBeer).toHaveBeenCalled();
  });

  fit('Should call logout function when \'Logout\' button in navbar is clicked in the navbar', fakeAsync(() => {
    // Spying on the logout function of the component
    spyOn(component, 'getRandomBeer');
	  let btn = fixture.nativeElement.querySelector('button');
	  console.log(btn);
   // btn.triggerEventHandler('click', null);
    // tick(); // si

    // Fetching the logout button from the navbar

		//fixture.detectChanges();
		// expect(component.getRandomBeer).toHaveBeenCalled();


  }));
});
