import { TestBed } from '@angular/core/testing';

import { BeersService } from './beers.service';
import { HttpClient } from '@angular/common/http';

class MockHttpClient {
  get() {}
}

describe('BeersService', () => {
  let http: HttpClient;
  let service: BeersService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        BeersService,
        {provide: HttpClient, useClass: MockHttpClient}
      ]});
    service = TestBed.inject(BeersService);
    http = TestBed.get(HttpClient);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it ('should call to get method with specific url', () => {
      spyOn(http, 'get').and.callThrough();
      service.getBeersList();
      expect(http.get).toHaveBeenCalledWith('https://api.punkapi.com/v2/beers');
  });
});
