import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BeersService {


  private punkApi = 'https://api.punkapi.com/v2/beers';


  constructor(private http: HttpClient) { }

  public getBeersList(params?: null): Observable<any> {
    const tempApi = params ? this.punkApi + params : this.punkApi;
    return this.http.get(tempApi);
  }

}
