import {Component, OnDestroy, OnInit} from '@angular/core';
import { Subscription } from 'rxjs';
import {BeersService} from '../_services/beers.service';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-beer-list',
  templateUrl: './beer-list.component.html',
  styleUrls: ['./beer-list.component.less'],
  providers: [BeersService]
})
export class BeerListComponent implements OnInit, OnDestroy {

  public beerList: Array<{}>;
  public searchForm: FormGroup;
  public  isFormSubmitted = false;

  private getBeerList: Subscription;

  get getFormData() { return this.searchForm.controls; }

  // tslint:disable-next-line:variable-name
  constructor(private _beerService: BeersService, private _fb: FormBuilder) { }

  ngOnInit(): void {
    this.searchForm = this._fb.group({
      searchKey: [null , [Validators.required , Validators.pattern('^[0-9A-Za-z\\s\\-]+$')]],
      searchBy: [null , Validators.required]
    });
    this.searchBeerList();
  }

  ngOnDestroy(): void {
    if (this.getBeerList) {
      this.getBeerList.unsubscribe();
    }
  }

  public onSubmit() {
    this.isFormSubmitted = true;
    if (this.searchForm.valid) {
      let searchType;
      // tslint:disable-next-line:max-line-length
      searchType = this.searchForm.get('searchBy').value === 'byName' ? '?beer_name=' +  this.searchForm.get('searchKey').value : '?beer_description=' +  this.searchForm.get('searchKey').value;
      this.searchBeerList(searchType);
    }

  }

  private searchBeerList(searchParams?: null) {
    this.getBeerList = this._beerService.getBeersList(searchParams).subscribe((list) => {
      this.beerList = list;
    }, (error) => {
      console.log(error);
    } , () => {

    });
  }

}
