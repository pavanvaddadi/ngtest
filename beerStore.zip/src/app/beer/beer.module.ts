import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BeerRoutingModule } from './beer-routing.module';
import { BeerStateComponent } from './beer-state.component';
import { BeerRandomComponent } from './beer-random/beer-random.component';
import { BeerListComponent } from './beer-list/beer-list.component';
import {ReactiveFormsModule} from "@angular/forms";


@NgModule({
  declarations: [BeerStateComponent, BeerRandomComponent, BeerListComponent],
  imports: [
    CommonModule,
    BeerRoutingModule,
    ReactiveFormsModule
  ]
})
export class BeerModule { }
