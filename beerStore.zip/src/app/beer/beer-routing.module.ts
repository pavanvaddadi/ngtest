import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {BeerStateComponent} from './beer-state.component';


const routes: Routes = [{
  path: 'beers',
  component: BeerStateComponent,
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BeerRoutingModule { }
