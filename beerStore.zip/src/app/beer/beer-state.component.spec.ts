import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BeerStateComponent } from './beer-state.component';
import {By} from '@angular/platform-browser';

describe('BeerStateComponent', () => {
  let component: BeerStateComponent;
  let fixture: ComponentFixture<BeerStateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BeerStateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BeerStateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load BeerRandomComponent component', () => {
    const getRandomComponent = fixture.debugElement.queryAll(By.css('app-beer-random'));
    expect(getRandomComponent).toBeDefined();
  });

  it('should load BeerListComponent component', () => {
    const getListComponent = fixture.debugElement.queryAll(By.css('app-beer-list'));
    expect(getListComponent).toBeDefined();
  });
});
