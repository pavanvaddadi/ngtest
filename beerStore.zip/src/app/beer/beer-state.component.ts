import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-beer-state',
  templateUrl: './beer-state.component.html',
  styleUrls: ['./beer-state.component.less']
})
export class BeerStateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
